from .list import ListView
from .create import CreateView
from .update import UpdateView
from .detail import DetailView
from .delete import DeleteView
from .duplicate import DuplicateView
from .base import ModuleView